package org.kaoriha.nbsb;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.util.Iterator;

public class NonBlockingServer {
	private ServerSocketChannel ssChannel;

	private Selector selector;

	public NonBlockingServer() throws IOException {
		ssChannel = ServerSocketChannel.open();
		ssChannel.socket().setReuseAddress(true);
		ssChannel.socket().bind(new InetSocketAddress(Constant.PORT));
		ssChannel.configureBlocking(false);

		selector = Selector.open();
		ssChannel.register(selector, SelectionKey.OP_ACCEPT,
				new AcceptHandler());
	}

	public void start() {
		IOHandler.classLoad();
		startMessage();

		try {
			while (selector.select() > 0) {
				for (Iterator it = selector.selectedKeys().iterator(); it.hasNext();) {
					SelectionKey key = (SelectionKey) it.next();
					it.remove();

					Handler handler = (Handler) key.attachment();
					handler.handle(key);
				}
			}
		} catch (ClosedChannelException ex) {
			System.err.println("Socket closed.");
			ex.printStackTrace();
		} catch (IOException ex) {
			System.err.println("IO error.");
			ex.printStackTrace();
		} finally {
			try {
				for (Iterator i = selector.keys().iterator(); i.hasNext();) {
					SelectionKey key = (SelectionKey) i.next();
					key.channel().close();
					key.cancel();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void startMessage() {
		System.out.println("NBSBench 2006/07/14");
		System.out.println("Non-Blocking ServerSocketChannel Benchmark");
		System.out
				.println("Try Apache HTTP server benchmarking tool (ab) to http://localhost:8000/");
		System.out.println("Use Ctrl-C to exit");
	}

	public static void main(String[] args) {
		try {
			NonBlockingServer server = new NonBlockingServer();
			server.start();
		} catch (ClosedChannelException ex) {
			System.err.println("Socket closed.");
			ex.printStackTrace();
		} catch (SocketException ex) {
			System.err.println("Socket error.");
			ex.printStackTrace();
		} catch (IOException ex) {
			System.err.println("IO error.");
			ex.printStackTrace();
		}
	}
}
