package org.kaoriha.nbsb;

public class Constant {
	public static final int PORT = 8000;
	public static final int SIZE = 1024 * 1024;
}
