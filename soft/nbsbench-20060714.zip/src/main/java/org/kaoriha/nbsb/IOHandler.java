package org.kaoriha.nbsb;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;

public class IOHandler implements Handler {
	public static void classLoad() {
		// Load this class now.
	}
	
	private final static int BUFFER_SIZE = 4096;

	private ByteBuffer readBuf = ByteBuffer.allocateDirect(BUFFER_SIZE);

	private ByteBuffer bodyBuf;

	private static byte[] HEADER;
	
	static {
		String[] HEADER_STR = {
				"HTTP/1.1 200 OK",
				"Date: Thu, 13 Jul 2006 15:31:24 GMT",
				"Server: NBSBench",
				"Accept-Ranges: bytes",
				"Content-Length: " + Constant.SIZE,
				"Content-Type: text/html",
			};
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < HEADER_STR.length; i++) {
			sb.append(HEADER_STR[i]);
			sb.append("\r\n");
		}
		sb.append("\r\n");
		HEADER = sb.toString().getBytes();
	}
	
	private static ByteBuffer BODY = ByteBuffer.allocateDirect(Constant.SIZE);
	
	static {
		for (int i = 0; i < BODY.capacity(); i++) {
			BODY.put((byte) ((i % 10) + 48));
		}
		BODY.position(0);
	}
	
	private boolean isHeaderWrote = false;

	public IOHandler() {
		bodyBuf = BODY.slice();
	}

	public void handle(SelectionKey key) {
		try {
			if (key.isReadable()) {
				read(key);
			}

			if (key.isWritable() && key.isValid()) {
				write(key);
			}
		} catch (IOException e) {
			try {
				key.channel().close();
			} catch (IOException e2) {
				// DO NOTHING
			}
			key.cancel();
		}
	}

	private void read(SelectionKey key) throws IOException {
		SocketChannel channel = (SocketChannel) key.channel();

		readBuf.clear();
		channel.read(readBuf);

		if (key.interestOps() != (SelectionKey.OP_READ | SelectionKey.OP_WRITE)) {
			key.interestOps(SelectionKey.OP_READ | SelectionKey.OP_WRITE);
		}
	}

	private void write(SelectionKey key) throws IOException {
		SocketChannel channel = (SocketChannel) key.channel();

		if (!isHeaderWrote) {
			channel.write(ByteBuffer.wrap(HEADER));
			isHeaderWrote = true;
		}
		if (bodyBuf.position() < bodyBuf.limit()) {
			channel.write(bodyBuf);
		} else {
			key.cancel();
			channel.close();
		}
	}
}
